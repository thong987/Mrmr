# Source-Profile-Html-Animation-V4
<h4>Đây là mã nguồn giới thiệu thông tin bản thân hiệu ứng bắt mắt, được viết bằng Css/Html/Javascript</h4>

<img
  src="https://i.imgur.com/YTvrQOq.png"
  alt="Alt text"
  title="Optional title"
  style="display: inline-block; margin: 0 auto; max-width: 300px">
